# Công cụ thực nghiệm trong bản nộp

Xem [hướng dẫn đầy đủ](../README.md#thực-nghiệm-và-biểu-đồ) từ thư mục Source.

- `python experiments.py --help` hoặc `python -m benchmarks.cli --help`
- `python -m benchmarks.summarize BATCH_DIRECTORY`
- `python -m benchmarks.level_groups --output benchmark-output/level-groups.csv`
- `python -m benchmarks.plot --help`

Công cụ và test không cần thư mục handoff hoặc Git. Dữ liệu gốc tại `benchmark-data/reference/`; mỗi lần đo mới phải dùng thư mục đầu ra mới.
