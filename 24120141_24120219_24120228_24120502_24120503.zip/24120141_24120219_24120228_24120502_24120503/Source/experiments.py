"""Benchmark entry point: python experiments.py --help."""
import multiprocessing as mp
from benchmarks.cli import main

if __name__ == "__main__":
    mp.freeze_support()
    main()
