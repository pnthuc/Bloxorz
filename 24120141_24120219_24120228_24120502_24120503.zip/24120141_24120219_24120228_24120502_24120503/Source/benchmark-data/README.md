# Dữ liệu thực nghiệm tham chiếu

Sao chép nguyên byte từ `handoff/quan/benchmarks/` và `handoff/quan/level-groups.csv` tại [repo](https://github.com/pnthuc/Bloxorz/).

Giữ raw.csv, summary.csv, run-config.json, environment.json và 300 JSON đường đi để xác thực số liệu và tái tạo biểu đồ. environment.json mô tả lần đo gốc. Không đưa biểu đồ đã có trong báo cáo vào đây. Kết quả chạy mới lưu vào benchmark-output với tên thư mục mới.
