# Bloxorz Solver và game Web 3D

[Link repo của nhóm](https://github.com/pnthuc/Bloxorz/)

Bản source nộp gồm game 25 màn, BFS, DFS, UCS, A*, phát lại lời giải và so sánh kết quả. Toàn bộ lệnh dưới đây chạy trong thư mục **Source** sau khi giải nén.

## Cài đặt và chạy game

Cần **Python 3.10 trở lên**, pip, mô-đun venv và trình duyệt có WebGL (Chrome, Edge, Firefox hoặc Brave). Lần cài thư viện cần Internet; game dùng Three.js, font, texture và âm thanh local. **Không cần Node.js hay npm để chơi hoặc chạy benchmark Python.**

Windows PowerShell:

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

Nếu Windows chỉ có lệnh `py`, thay hai lệnh `python` đầu bằng `py -3`. Gọi trực tiếp Python trong venv như trên không cần thay ExecutionPolicy. Có thể kích hoạt venv bằng lệnh sau nếu máy cho phép:

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
``` 

macOS hoặc Linux:

```bash
python3 --version
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py
```

Mở **http://127.0.0.1:5000** nếu trình duyệt chưa tự mở. Giữ terminal đang chạy; nhấn `Ctrl+C` để dừng. Nếu cổng 5000 đang bận, dừng phiên game cũ hoặc chạy `python -m flask --app main run --host 127.0.0.1 --port 5001`, rồi mở http://127.0.0.1:5001. Không mở trực tiếp file HTML bằng `file://`.

**Các lệnh `python` phía dưới giả định venv đã kích hoạt.** Trên PowerShell có thể thay `python` bằng `.\.venv\Scripts\python.exe` ở mọi lệnh. Nếu báo không có Flask, kiểm tra đã cài requirements bằng đúng Python trong venv. Nếu màn 3D không hiện, kiểm tra WebGL và tăng tốc phần cứng của trình duyệt.

## Điều khiển và solver

Game mở trực tiếp vào bàn chơi. Nhấn **Menu** hoặc **Esc**, chọn **Chọn màn** để đổi màn hoặc **AI Solver** để chọn thuật toán và xem lời giải. Giao diện có phát lại và so sánh thuật toán.

| Thao tác | Phím hoặc chuột |
| --- | --- |
| Lăn khối theo hàng và cột của bàn | Mũi tên hoặc W A S D; giữ phím để lăn liên tục |
| Đổi khối đang điều khiển khi tách đôi | Space |
| Chơi lại màn | R |
| Toàn cảnh hoặc nhìn gần khối | C hoặc F |
| Mở hoặc đóng menu | Esc |
| Xoay hoặc thu phóng | Kéo chuột hoặc cuộn con lăn |

Khối phải đứng thẳng trên lỗ đích để thắng. Ô fragile không chịu được khối đứng thẳng. Công tắc nhẹ nhận mọi tư thế; công tắc nặng cần đứng thẳng. Công tắc split tách khối; dùng Space để chọn khối, đưa hai khối về cạnh nhau để ghép. Hướng lăn không đổi theo góc camera.

## Kiểm thử Python

```powershell
python -m unittest discover -s tests -t . -v
python run_tests.py --cases 1 2 3 4
python run_tests.py --solver astar
```

Lệnh đầu chạy unit/regression test engine, API, solver và công cụ thực nghiệm. `run_tests.py` cũng chạy các test này, rồi kiểm tra lời giải thật bằng replay trên ca được chọn. Exit code: `0` PASS, `1` FAIL, `2` PENDING. Số lượng test hiện tại xem ở kết quả chạy, không suy từ README của repo cũ.

## Kiểm thử UI tùy chọn

**Node.js 18 trở lên và `npm ci` trong `Source/tests` chỉ phục vụ test UI.** Các test dùng jsdom và canvas; không thay thế việc mở game bằng trình duyệt WebGL thật.

```powershell
cd tests
npm ci
cd ..
```

PowerShell:

```powershell
python run_tests.py --ui --cases 1 2 3 4
```

macOS hoặc Linux:

```bash
python run_tests.py --ui --cases 1 2 3 4
```

Cũng có thể chạy riêng UI bằng `npm test` trong `tests` sau khi đặt `PYTHON` trỏ đến Python của venv. `package-lock.json` được giữ để `npm ci` cài đúng phiên bản; `node_modules` không nằm trong gói nộp.

## Thực nghiệm và biểu đồ

Từ **Source**, chạy nhanh một màn với cả bốn thuật toán rồi tổng hợp:

```powershell
python experiments.py --levels 1 --solvers bfs dfs ucs astar --repeats 1 --timeout 10 --output-dir benchmark-output/smoke
python -m benchmarks.summarize benchmark-output/smoke
```

Tái lập cấu hình 300 lượt (25 màn × 4 thuật toán × 3 lần):

```powershell
python experiments.py --levels all --solvers bfs dfs ucs astar --repeats 3 --timeout 120 --output-dir benchmark-output/full-run
python -m benchmarks.summarize benchmark-output/full-run
```

`python -m benchmarks.cli` tương đương `python experiments.py`. **Mỗi lần đo chọn một thư mục đầu ra mới**; công cụ từ chối ghi đè. Tổng hợp cũng từ chối thay `summary.csv` có sẵn. Thời gian và bộ nhớ có thể khác giữa các máy; đây là phép đo mới, không thay dữ liệu đã bàn giao.

Mỗi batch có `raw.csv`, `runs/*.json`, `run-config.json`, `environment.json`; bước tổng hợp tạo `summary.csv`. Các chỉ số: thời gian tìm kiếm (ms), đỉnh cấp phát Python từ tracemalloc (KiB), node mở rộng, số hành động và `path_cost` tính lại qua replay. Không dùng thời gian animation làm thời gian tìm kiếm, không đồng nhất `total_cost` của mọi solver với cost chung.

Chỉ khi cần tái tạo hình và bảng mới cài thêm matplotlib:

```powershell
python -m pip install -r requirements-charts.txt
python -m benchmarks.plot --batch benchmark-data/reference --groups benchmark-data/level-groups.csv --output-dir benchmark-output/reference-plots
```

Lệnh đọc 300 lượt đo gốc và xuất 10 PNG cùng `result-tables.csv`. Không chạy lại solver khi vẽ. Dữ liệu tham chiếu được sao chép nguyên byte từ snapshot repo; chi tiết tại [benchmark-data/README.md](benchmark-data/README.md). Muốn vẽ batch mới, thay `--batch` bằng thư mục kết quả mới. Có thể tạo lại nhóm màn bằng `python -m benchmarks.level_groups --output benchmark-output/level-groups.csv`.

## Cấu trúc và tài nguyên

```text
Source/
  README.md                Hướng dẫn cho bản giải nén
  main.py                  Khởi chạy Flask và mở trình duyệt
  game_logic.py            Tên tương thích, xuất luật từ core
  experiments.py           Tên tương thích, gọi benchmarks.cli
  run_tests.py             Kiểm thử tổng hợp
  requirements.txt         Thư viện chạy game
  requirements-charts.txt   Thư viện vẽ tùy chọn
  core/ web/ solvers/       Luật game, API và bốn thuật toán
  levels/                  30 file JSON
  static/ templates/       Giao diện và toàn bộ tài nguyên local
  tests/                   Test Python, UI, package và lockfile
  benchmarks/              Đo, tổng hợp, nhóm màn và vẽ
  benchmark-data/           Số liệu gốc cần đối chiếu báo cáo
```

Giữ giấy phép Three.js tại `static/vendor/THREE-LICENSE.txt` và giấy phép font tại `static/fonts/OFL.txt`. Các asset khác được giữ nguyên từ snapshot, không suy diễn giấy phép bổ sung. Không kèm `.git`, `.venv`, `__pycache__`, `node_modules`, cache, log hoặc file tạm. Tạo các thư mục môi trường và kết quả mới trên máy người chạy khi cần.
