# Dữ liệu thực nghiệm tham chiếu

Sao chép nguyên byte từ `handoff/quan/benchmarks/` và `handoff/quan/level-groups.csv` tại commit `14baf1df451db2134b2d92f2cf15aa09d7d21e47`.

Giữ raw.csv, summary.csv, run-config.json, environment.json và 300 JSON đường đi để xác thực số liệu và tái tạo biểu đồ. environment.json mô tả lần đo gốc, không phải lần kiểm tra P04. Không đưa biểu đồ đã có trong báo cáo vào đây. Kết quả chạy mới lưu vào benchmark-output với tên thư mục mới.
